"use client"

import { useState, useEffect } from "react"
import type { Task } from "@/types/task"
import TaskList from "./task-list"
import TaskForm from "./task-form"
import TaskAnalytics from "./task-analytics"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { fetchTasks, analyzeTasksWithAI } from "@/actions/task-actions"
import { useToast } from "@/hooks/use-toast"

export default function TaskDashboard() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [aiSuggestions, setAiSuggestions] = useState<string>("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    loadTasks()
  }, [])

  const loadTasks = async () => {
    try {
      const loadedTasks = await fetchTasks()
      setTasks(loadedTasks)
    } catch (error) {
      toast({
        title: "Error loading tasks",
        description: "Please try again later",
        variant: "destructive",
      })
    }
  }

  const handleTaskAdded = (newTask: Task) => {
    setTasks((prev) => [...prev, newTask])
  }

  const handleTaskUpdated = (updatedTask: Task) => {
    setTasks((prev) => prev.map((task) => (task.id === updatedTask.id ? updatedTask : task)))
  }

  const handleTaskDeleted = (taskId: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== taskId))
  }

  const handleAnalyzeTasks = async () => {
    if (tasks.length === 0) {
      toast({
        title: "No tasks to analyze",
        description: "Add some tasks first",
        variant: "destructive",
      })
      return
    }

    setIsAnalyzing(true)
    try {
      const analysis = await analyzeTasksWithAI(tasks)
      setAiSuggestions(analysis)
    } catch (error) {
      toast({
        title: "AI analysis failed",
        description: "Please try again later",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="space-y-8">
      <Tabs defaultValue="tasks" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="add">Add Task</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Tasks</h2>
            <Button onClick={handleAnalyzeTasks} disabled={isAnalyzing || tasks.length === 0} variant="outline">
              {isAnalyzing ? "Analyzing..." : "Analyze with AI"}
            </Button>
          </div>

          {aiSuggestions && (
            <div className="bg-secondary/50 p-4 rounded-lg mb-4">
              <h3 className="font-medium mb-2">AI Suggestions:</h3>
              <p className="text-sm">{aiSuggestions}</p>
            </div>
          )}

          <TaskList tasks={tasks} onTaskUpdated={handleTaskUpdated} onTaskDeleted={handleTaskDeleted} />
        </TabsContent>

        <TabsContent value="add">
          <TaskForm onTaskAdded={handleTaskAdded} />
        </TabsContent>

        <TabsContent value="analytics">
          <TaskAnalytics tasks={tasks} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

