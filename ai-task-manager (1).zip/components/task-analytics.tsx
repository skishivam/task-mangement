"use client"

import { useMemo } from "react"
import type { Task } from "@/types/task"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { CheckCircle2, Clock, AlertTriangle, BarChart3 } from "lucide-react"

interface TaskAnalyticsProps {
  tasks: Task[]
}

export default function TaskAnalytics({ tasks }: TaskAnalyticsProps) {
  const stats = useMemo(() => {
    const total = tasks.length
    const completed = tasks.filter((task) => task.completed).length
    const pending = total - completed

    const highPriority = tasks.filter((task) => task.priority.toLowerCase() === "high" && !task.completed).length

    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0

    const priorityDistribution = {
      high: tasks.filter((task) => task.priority.toLowerCase() === "high").length,
      medium: tasks.filter((task) => task.priority.toLowerCase() === "medium").length,
      low: tasks.filter((task) => task.priority.toLowerCase() === "low").length,
    }

    return {
      total,
      completed,
      pending,
      highPriority,
      completionRate,
      priorityDistribution,
    }
  }, [tasks])

  if (tasks.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">No tasks yet. Add tasks to see analytics.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold">{stats.completionRate}%</div>
              <Progress value={stats.completionRate} className="h-2 mt-2 w-full" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Task Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center">
                <CheckCircle2 className="h-5 w-5 mr-2 text-green-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold">{stats.completed}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2 text-blue-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold">{stats.pending}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">High Priority Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <AlertTriangle className="h-8 w-8 mr-3 text-red-500" />
              <div className="text-3xl font-bold">{stats.highPriority}</div>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              {stats.highPriority > 0 ? "Requires immediate attention" : "No high priority tasks pending"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="h-5 w-5 mr-2" />
            Priority Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">High</span>
                <span className="text-sm text-muted-foreground">{stats.priorityDistribution.high} tasks</span>
              </div>
              <Progress
                value={(stats.priorityDistribution.high / stats.total) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-red-500"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Medium</span>
                <span className="text-sm text-muted-foreground">{stats.priorityDistribution.medium} tasks</span>
              </div>
              <Progress
                value={(stats.priorityDistribution.medium / stats.total) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-yellow-500"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">Low</span>
                <span className="text-sm text-muted-foreground">{stats.priorityDistribution.low} tasks</span>
              </div>
              <Progress
                value={(stats.priorityDistribution.low / stats.total) * 100}
                className="h-2 bg-muted"
                indicatorClassName="bg-green-500"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

