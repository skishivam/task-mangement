export function formatDistanceToNow(date: Date): string {
  const now = new Date()
  const diffInDays = Math.floor((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

  if (diffInDays < 0) {
    return diffInDays === -1 ? "Due yesterday" : `Overdue by ${Math.abs(diffInDays)} days`
  }

  if (diffInDays === 0) return "Due today"
  if (diffInDays === 1) return "Due tomorrow"

  return `Due in ${diffInDays} days`
}

