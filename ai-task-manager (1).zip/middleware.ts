import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const sessionToken = request.cookies.get("session_token")?.value
  const isAuthPage = request.nextUrl.pathname === "/login" || request.nextUrl.pathname === "/signup"

  // If the user is on an auth page and has a session, redirect to the dashboard
  if (isAuthPage && sessionToken) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  // If the user is not on an auth page and doesn't have a session, redirect to login
  if (!isAuthPage && !sessionToken) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}

