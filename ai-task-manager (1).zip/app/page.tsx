import { redirect } from "next/navigation"
import TaskDashboard from "@/components/task-dashboard"
import { getCurrentUser } from "@/actions/auth-actions"

export default async function Home() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/login")
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">AI Task Manager</h1>
      <p className="text-center text-muted-foreground mb-8">Welcome back, {user.name}</p>
      <TaskDashboard />
    </main>
  )
}

