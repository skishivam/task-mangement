"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import type { SignupData, UserCredentials, AuthResult, User, Session } from "@/types/auth"

// In-memory user store (in a real app, you'd use a database)
const users: (User & { password: string })[] = []

// In-memory session store (in a real app, you'd use a proper session management system)
const sessions: Record<string, Session> = {}

export async function signup(data: SignupData): Promise<AuthResult> {
  // Check if user already exists
  const existingUser = users.find((user) => user.email === data.email)
  if (existingUser) {
    return {
      success: false,
      message: "User with this email already exists",
    }
  }

  // In a real app, you would hash the password
  const newUser = {
    id: Date.now().toString(),
    email: data.email,
    name: data.name,
    password: data.password, // In a real app, this would be hashed
    createdAt: new Date().toISOString(),
  }

  users.push(newUser)

  // Create session
  const { password, ...userWithoutPassword } = newUser
  const session = createSession(userWithoutPassword)

  return {
    success: true,
    message: "Account created successfully",
    user: userWithoutPassword,
  }
}

export async function login(credentials: UserCredentials): Promise<AuthResult> {
  // Find user
  const user = users.find((user) => user.email === credentials.email)

  // Check if user exists and password matches
  if (!user || user.password !== credentials.password) {
    return {
      success: false,
      message: "Invalid email or password",
    }
  }

  // Create session
  const { password, ...userWithoutPassword } = user
  const session = createSession(userWithoutPassword)

  return {
    success: true,
    message: "Logged in successfully",
    user: userWithoutPassword,
  }
}

export async function logout(): Promise<void> {
  const sessionToken = cookies().get("session_token")?.value

  if (sessionToken && sessions[sessionToken]) {
    delete sessions[sessionToken]
    cookies().delete("session_token")
  }

  redirect("/login")
}

export async function getCurrentUser(): Promise<User | null> {
  const sessionToken = cookies().get("session_token")?.value

  if (!sessionToken || !sessions[sessionToken]) {
    return null
  }

  const session = sessions[sessionToken]

  // Check if session is expired
  if (new Date(session.expires) < new Date()) {
    delete sessions[sessionToken]
    cookies().delete("session_token")
    return null
  }

  return session.user
}

function createSession(user: User): Session {
  // Create a session that expires in 24 hours
  const expires = new Date()
  expires.setHours(expires.getHours() + 24)

  const session: Session = {
    user,
    expires: expires.toISOString(),
  }

  // Generate a random session token
  const sessionToken = Math.random().toString(36).substring(2, 15)

  // Store the session
  sessions[sessionToken] = session

  // Set the session cookie
  cookies().set("session_token", sessionToken, {
    expires,
    httpOnly: true,
    path: "/",
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
  })

  return session
}

