"use server"

import { revalidatePath } from "next/cache"
import type { Task } from "@/types/task"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { getCurrentUser } from "./auth-actions"

// In-memory storage for tasks (in a real app, you'd use a database)
const tasks: (Task & { userId: string })[] = []

export async function createTask(taskData: Omit<Task, "id">): Promise<Task> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  const newTask: Task & { userId: string } = {
    id: Date.now().toString(),
    title: taskData.title,
    description: taskData.description || "",
    priority: taskData.priority,
    dueDate: taskData.dueDate,
    completed: false,
    createdAt: new Date().toISOString(),
    userId: user.id,
  }

  tasks.push(newTask)
  revalidatePath("/")

  // Return task without userId for client
  const { userId, ...taskWithoutUserId } = newTask
  return taskWithoutUserId
}

export async function updateTask(taskData: Task): Promise<Task> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  const index = tasks.findIndex((task) => task.id === taskData.id && task.userId === user.id)

  if (index === -1) {
    throw new Error("Task not found")
  }

  tasks[index] = {
    ...tasks[index],
    ...taskData,
    userId: user.id,
  }

  revalidatePath("/")

  // Return task without userId for client
  const { userId, ...taskWithoutUserId } = tasks[index]
  return taskWithoutUserId
}

export async function deleteTask(taskId: string): Promise<void> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  const index = tasks.findIndex((task) => task.id === taskId && task.userId === user.id)

  if (index === -1) {
    throw new Error("Task not found")
  }

  tasks.splice(index, 1)
  revalidatePath("/")
}

export async function fetchTasks(): Promise<Task[]> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  // Filter tasks by user ID and sort them
  const userTasks = tasks
    .filter((task) => task.userId === user.id)
    .map(({ userId, ...task }) => task) // Remove userId from returned tasks
    .sort((a, b) => {
      // Sort by completed (incomplete first)
      if (a.completed !== b.completed) {
        return a.completed ? 1 : -1
      }

      // Then by priority (high to low)
      const priorityOrder = { high: 0, medium: 1, low: 2 }
      const aPriority = a.priority.toLowerCase() as keyof typeof priorityOrder
      const bPriority = b.priority.toLowerCase() as keyof typeof priorityOrder

      if (priorityOrder[aPriority] !== priorityOrder[bPriority]) {
        return priorityOrder[aPriority] - priorityOrder[bPriority]
      }

      // Then by due date (earliest first)
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    })

  return userTasks
}

export async function analyzeTasksWithAI(tasks: Task[]): Promise<string> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  try {
    // Convert tasks to a string format for the AI to analyze
    const tasksString = tasks
      .map((task) => {
        return `- ${task.title} (Priority: ${task.priority}, Due: ${new Date(task.dueDate).toLocaleDateString()}, ${task.completed ? "Completed" : "Pending"})`
      })
      .join("\n")

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: `Analyze these tasks and provide productivity suggestions, prioritization advice, and time management tips:
      
      ${tasksString}
      
      Provide a concise analysis (max 150 words) focusing on:
      1. Task prioritization suggestions
      2. Time management advice
      3. Any patterns or improvements you notice`,
      system:
        "You are a productivity assistant that helps users manage their tasks effectively. Be concise and practical.",
    })

    return text
  } catch (error) {
    console.error("AI analysis error:", error)
    return "Unable to analyze tasks at this time. Please try again later."
  }
}

export async function generateTaskSuggestion(): Promise<{
  title: string
  description: string
  priority: string
}> {
  const user = await getCurrentUser()

  if (!user) {
    throw new Error("User not authenticated")
  }

  try {
    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt: "Generate a realistic task suggestion for a productivity app.",
      system: `Generate a JSON object with a task suggestion. Include:
      - title: A concise task title
      - description: A brief description of the task
      - priority: Either "Low", "Medium", or "High"
      
      Format as valid JSON without explanation.`,
    })

    // Parse the JSON response
    return JSON.parse(text)
  } catch (error) {
    console.error("Task suggestion generation error:", error)
    return {
      title: "Review weekly goals",
      description: "Take 30 minutes to review progress on weekly goals and adjust priorities accordingly.",
      priority: "Medium",
    }
  }
}

