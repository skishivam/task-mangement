export interface User {
  id: string
  email: string
  name: string
  createdAt: string
}

export interface UserCredentials {
  email: string
  password: string
}

export interface SignupData extends UserCredentials {
  name: string
}

export interface AuthResult {
  success: boolean
  message: string
  user?: User
}

export interface Session {
  user: User
  expires: string
}

